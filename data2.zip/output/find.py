import os

# Define the special character to search for
special_character = 'ໆ'

# Get the current directory's path
current_directory = os.getcwd()

# List all files in the current directory
files_in_directory = os.listdir(current_directory)

# Filter out txt files
txt_files = [file for file in files_in_directory if file.endswith('.txt')]

# Check each txt file for the special character
for txt_file in txt_files:
    with open(txt_file, 'r', encoding='utf-8') as file:
        contents = file.read()
        if special_character in contents:
            print(f'Found "{special_character}" in: {txt_file}')
